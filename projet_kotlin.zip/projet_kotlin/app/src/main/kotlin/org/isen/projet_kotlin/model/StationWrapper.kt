package org.isen.projet_kotlin.model

import com.google.gson.annotations.SerializedName

data class StationWrapper(
    @SerializedName("fields")
    val station: Station? = null
)

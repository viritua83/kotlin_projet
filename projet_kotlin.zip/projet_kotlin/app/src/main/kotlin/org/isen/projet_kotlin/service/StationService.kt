package org.isen.projet_kotlin.service

import org.isen.projet_kotlin.model.StationResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query


interface StationService {
    @GET("api/explore/v2.1/catalog/datasets/prix-des-carburants-j-1/records")
    fun getStations(@Query("limit") limit: Int = 100): Call<StationResponse>
}

package org.isen.projet_kotlin.model

import com.google.gson.annotations.SerializedName

data class Timetable(
    @SerializedName("Dimanche")
    val dimanche: TimetableDay? = null,

    @SerializedName("Lundi")
    val lundi: TimetableDay? = null,

    @SerializedName("Mardi")
    val mardi: TimetableDay? = null,

    @SerializedName("Mercredi")
    val mercredi: TimetableDay? = null,

    @SerializedName("Jeudi")
    val jeudi: TimetableDay? = null,

    @SerializedName("Vendredi")
    val vendredi: TimetableDay? = null,

    @SerializedName("Samedi")
    val samedi: TimetableDay? = null
)

data class TimetableDay(
    @SerializedName("ouverture")
    val ouverture: String? = null,

    @SerializedName("fermeture")
    val fermeture: String? = null,

    @SerializedName("ouvert")
    val ouvert: Int? = null
)

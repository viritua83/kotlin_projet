package org.isen.projet_kotlin.util

import org.isen.projet_kotlin.service.StationService
import okhttp3.OkHttpClient
import com.github.kittinunf.fuel.httpGet

import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object DataSourceManager {

    private const val BASE_URL_PRINCIPALE = "https://public.opendatasoft.com/"

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    private val httpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .build()

    private val retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL_PRINCIPALE)
            .addConverterFactory(GsonConverterFactory.create())  // Utiliser Gson
            .client(httpClient)
            .build()
    }

    fun getPrincipaleService(): StationService {
        return retrofit.create(StationService::class.java)
    }
}
fun JSonGet(URL: String){
    URL.httpGet().responseString{
        request, response, result ->
        println(result.get())
    }
}

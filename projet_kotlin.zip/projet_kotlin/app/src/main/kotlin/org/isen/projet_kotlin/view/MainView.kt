package org.isen.projet_kotlin.view

import org.isen.projet_kotlin.controller.MainController
import org.isen.projet_kotlin.service.StationService
import org.isen.projet_kotlin.model.StationResponse

import javax.swing.*
import javax.swing.table.DefaultTableModel

import org.isen.projet_kotlin.model.Station
import java.awt.BorderLayout


class MainView : JFrame("Recherche Stations Essence") {

    private val villeField = JTextField(20)
    private val rechercherButton = JButton("Rechercher")
    private val stationTableModel = DefaultTableModel(arrayOf("Nom", "Adresse", "Carburants", "Prix Gazole"), 0)
    private val stationTable = JTable(stationTableModel)

    private val controller = MainController(this)

    init {
        layout = BorderLayout()

        // Barre de recherche
        val searchPanel = JPanel().apply {
            add(JLabel("Ville :"))
            add(villeField)
            add(rechercherButton)
        }

        add(searchPanel, BorderLayout.NORTH)
        add(JScrollPane(stationTable), BorderLayout.CENTER)

        // Action du bouton "Rechercher"
        rechercherButton.addActionListener {
            val ville = villeField.text
            if (ville.isNotBlank()) {
                controller.rechercherStations(ville)
            } else {
                JOptionPane.showMessageDialog(this, "Veuillez entrer une ville.", "Erreur", JOptionPane.ERROR_MESSAGE)
            }
        }

        defaultCloseOperation = EXIT_ON_CLOSE
        setSize(800, 600)
        isVisible = true
    }

    // Méthode appelée pour afficher les résultats
    fun updateStationTable(stations: List<Station>) {
        // Effacer les anciennes données
        stationTableModel.setRowCount(0)

        // Ajouter les nouvelles données
        for (station in stations) {
            stationTableModel.addRow(arrayOf(
                station.nom ?: "Inconnu",
                "${station.adresse}, ${station.ville}",
                station.carburants.joinToString(", "),
                station.prixGazole?.toString() ?: "N/A"
            ))
        }
    }
}

package org.isen.projet_kotlin.model

import com.google.gson.annotations.SerializedName

data class Station(
    val nom: String?,
    val adresse: String?,
    @SerializedName("com_arm_name") val ville: String?,
    val carburants: List<String>,
    val prixGazole: Double?
)

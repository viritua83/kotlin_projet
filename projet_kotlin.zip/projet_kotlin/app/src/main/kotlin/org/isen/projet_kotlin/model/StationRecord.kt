package org.isen.projet_kotlin.model



data class StationRecord(
    val station: Station?
)

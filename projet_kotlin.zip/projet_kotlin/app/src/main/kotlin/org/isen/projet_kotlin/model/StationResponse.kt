package org.isen.projet_kotlin.model

import com.google.gson.annotations.SerializedName

data class StationResponse(
    val records: List<StationRecord>
)

package org.isen.projet_kotlin.controller

import  org.isen.projet_kotlin.model.Station
import  org.isen.projet_kotlin.model.StationResponse

import  org.isen.projet_kotlin.util.DataSourceManager


import com.github.kittinunf.fuel.httpGet
import com.github.kittinunf.fuel.gson.responseObject
import org.isen.projet_kotlin.view.MainView

class MainController(private val view: MainView) {

    fun rechercherStations(ville: String) {
        val url = "https://public.opendatasoft.com/api/explore/v2.1/catalog/datasets/prix-des-carburants-j-1/records?limit=100"

        url.httpGet().responseObject<StationResponse> { _, _, result ->
            result.fold(success = { response ->
                val stations = response.records
                    .mapNotNull { it.station }
                    .filter { it.ville.equals(ville, ignoreCase = true) }

                // On met à jour la vue avec les stations trouvées
                view.updateStationTable(stations)
            }, failure = {
                url.httpGet().responseObject<StationResponse> { _, response, result ->
                    result.fold(
                        success = { stationResponse ->
                            println("Données récupérées : ${stationResponse.records.size} enregistrements")

                            val stations = stationResponse.records
                                .mapNotNull { it.station }
                                .filter { it.ville.equals(ville, ignoreCase = true) }

                            println("Stations filtrées pour $ville : ${stations.size}")
                            view.updateStationTable(stations)
                        },
                        failure = { error ->
                            println("Erreur réseau : ${error.exception}")
                            println("Détails de l'erreur : ${error.message}")
                            println("Statut HTTP : ${response.statusCode}")
                            println("Body de la réponse : ${response.body().asString("application/json")}")
                        }
                    )
                }

            })
        }
    }
}

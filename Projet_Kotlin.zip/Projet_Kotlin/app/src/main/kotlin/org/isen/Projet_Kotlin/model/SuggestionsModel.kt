package org.isen.Projet_Kotlin.model

// Modèle pour les suggestions de villes
class SuggestionsModel {
    private val suggestions = mutableListOf<String>()

    fun addSuggestion(suggestion: String) {
        if (!suggestions.contains(suggestion)) {
            suggestions.add(suggestion)
        }
    }

    fun getSuggestions(): List<String> {
        return suggestions
    }
}
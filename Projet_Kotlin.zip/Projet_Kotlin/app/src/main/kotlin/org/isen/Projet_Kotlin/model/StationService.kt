package org.isen.Projet_Kotlin.model


import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue
import okhttp3.OkHttpClient
import okhttp3.Request

class StationService {

    private val client = OkHttpClient()
    private val objectMapper = jacksonObjectMapper()

    private val urlPrincipale = "https://public.opendatasoft.com/api/explore/v2.1/catalog/datasets/prix-des-carburants-j-1/exports/json"
    private val urlSecondaire = "https://www.prix-carburants.gouv.fr/rubrique/opendata"
    private var usingMainSource: Boolean = true
    private var useMainSource = true

    fun toggleSource() {
        useMainSource = !useMainSource
    }

    fun fetchStations(city: String): List<Station> {
        val url = if (useMainSource) urlPrincipale else urlSecondaire
        val request = Request.Builder().url(url).build()

        return try {
            val response = client.newCall(request).execute()
            if (!response.isSuccessful) throw Exception("Erreur lors du téléchargement des données")

            val jsonData = response.body?.string() ?: throw Exception("Réponse vide")
            parseStations(jsonData, city)
        } catch (e: Exception) {
            println("Erreur : ${e.message}")
            emptyList()
        }
    }

    fun isUsingMainSource(): Boolean {
        return usingMainSource
    }
    private fun parseStations(jsonData: String, city: String): List<Station> {
        val rootNode: List<JsonNode> = objectMapper.readValue(jsonData)
        return rootNode.mapNotNull { node ->
            val ville = node["ville"]?.asText() ?: return@mapNotNull null
            if (!ville.contains(city, ignoreCase = true)) return@mapNotNull null

            val nom = node["nom"]?.asText() ?: "Nom inconnu"
            val adresse = node["adresse"]?.asText() ?: "Adresse inconnue"
            val carburants = mutableMapOf<String, Double>()

            node["prix"]?.fields()?.forEach { (carburant, prix) ->
                carburants[carburant] = prix.asDouble()
            }

            Station(nom, adresse, ville, carburants, toilettes = false, gonflage = false, boutique = false)
        }
    }
}

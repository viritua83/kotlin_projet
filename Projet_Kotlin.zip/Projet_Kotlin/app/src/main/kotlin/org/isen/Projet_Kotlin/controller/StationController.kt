package org.isen.Projet_Kotlin.controller
import org.isen.Projet_Kotlin.model.Station
import org.isen.Projet_Kotlin.model.StationModel
import org.isen.Projet_Kotlin.view.IStationView
import org.isen.Projet_Kotlin.model.StationService
import okhttp3.OkHttpClient
import okhttp3.Request

class StationController(private val model: StationModel) {
    private val service = StationService()  // Initialisation du service dans le contrôleur
    private val views = mutableListOf<IStationView>()

    fun registerView(view: IStationView) {
        views.add(view)
        model.addPropertyChangeListener(view)
    }
    fun searchStations(city: String) {
        val stations = service.fetchStations(city)
        model.updateStations(stations)
    }

    fun toggleSource() {
        service.toggleSource()
    }
    fun isUsingMainSource(): Boolean {
        return service.isUsingMainSource()
    }
    fun testAPIConnection() {
        val client = OkHttpClient()
        val url = "https://public.opendatasoft.com/api/explore/v2.1/catalog/datasets/prix-des-carburants-j-1/records"

        val request = Request.Builder()
            .url(url)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    println("✅ Connexion réussie !")
                    println("🔹 Exemple de données : ${response.body?.string()?.take(500)}")  // Affiche un extrait
                } else {
                    println("❌ Erreur : ${response.code}")
                }
            }
        } catch (e: Exception) {
            println("🚨 Problème lors de l'accès à l'API : ${e.message}")
        }
    }


}


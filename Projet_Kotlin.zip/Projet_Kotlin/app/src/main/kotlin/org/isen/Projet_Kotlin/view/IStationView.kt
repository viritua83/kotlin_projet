package org.isen.Projet_Kotlin.view



import javax.swing.*
import java.awt.*
import java.beans.PropertyChangeEvent
import java.beans.PropertyChangeListener


interface IStationView: PropertyChangeListener {
    fun display()
    fun close()
}
package org.isen.Projet_Kotlin.model

data class Station(
    val nom: String,
    val adresse: String,
    val ville: String,
    val carburants: Map<String, Double>, // Carburant -> Prix
    val toilettes: Boolean,
    val gonflage: Boolean,
    val boutique: Boolean
)

package org.isen.Projet_Kotlin.view
import org.isen.Projet_Kotlin.controller.StationController
import org.isen.Projet_Kotlin.model.SuggestionsModel
import javax.swing.*
import java.awt.*

import java.awt.event.KeyAdapter
import java.awt.event.KeyEvent
import java.beans.PropertyChangeEvent
import java.beans.PropertyChangeListener
import org.isen.Projet_Kotlin.model.Station
import javax.swing.table.DefaultTableModel

class StationView(private val controller: StationController) : IStationView, JFrame("Stations") {
    private val listModel = DefaultListModel<String>()
    private val stationList = JList(listModel)
    private val suggestionsModel = SuggestionsModel()  // Ajout de suggestionsModel
    private val tableModel = DefaultTableModel(arrayOf("Nom", "Adresse", "Ville", "Carburants"), 0)
    private val table = JTable(tableModel)

    init {
        controller.registerView(this)
        preferredSize = Dimension(400, 300)
        defaultCloseOperation = WindowConstants.EXIT_ON_CLOSE

        contentPane.layout = BorderLayout()

        val searchPanel = JPanel()
        val searchField = JTextField(20)
        val searchButton = JButton("Rechercher")

        searchPanel.add(searchField)
        searchPanel.add(searchButton)

        contentPane.add(searchPanel, BorderLayout.NORTH)
        contentPane.add(JScrollPane(stationList), BorderLayout.CENTER)
        pack()

        searchButton.addActionListener {
            val city = searchField.text
            if (city.isNotEmpty()) {
                controller.searchStations(city)
                suggestionsModel.addSuggestion(city) // Ajout à suggestionsModel
            }
        }
    }
    init {
        // Ajout du tableau à l'UI
        val tableScrollPane = JScrollPane(table)
        add(tableScrollPane, BorderLayout.SOUTH)
    }

    // Fonction de mise à jour des résultats
    override fun propertyChange(evt: PropertyChangeEvent) {
        if (evt.propertyName == "stations") {
            val stations = evt.newValue as List<Station>
            tableModel.setRowCount(0)  // Nettoie le tableau
            stations.forEach { station ->
                tableModel.addRow(arrayOf(
                    station.nom,
                    station.adresse,
                    station.ville,
                    station.carburants.map { "${it.key}: ${it.value}€" }.joinToString(", ")
                ))
            }
        }
    }

    override fun display() {
        isVisible = true
    }

    override fun close() {
        isVisible = false
    }

    }


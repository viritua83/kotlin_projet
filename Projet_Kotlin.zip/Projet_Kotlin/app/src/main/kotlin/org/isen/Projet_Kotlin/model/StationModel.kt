package org.isen.Projet_Kotlin.model


import java.beans.PropertyChangeSupport
import java.beans.PropertyChangeListener
import kotlin.properties.Delegates
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

class StationModel {
    private val pcs = PropertyChangeSupport(this)
    private val stations = mutableListOf<Station>()
    private val client = OkHttpClient()

    fun fetchStationsFromAPI(city: String) {
        val url = "https://public.opendatasoft.com/api/explore/v2.1/catalog/datasets/prix-des-carburants-j-1/records?where=com_arm_name='${city.uppercase()}'"

        val request = Request.Builder()
            .url(url)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val jsonData = response.body?.string()
                    if (jsonData != null) {
                        val stationsList = parseStations(jsonData)
                        updateStations(stationsList)
                    }
                } else {
                    println("❌ Erreur API: ${response.code}")
                }
            }
        } catch (e: Exception) {
            println("🚨 Problème d'accès à l'API : ${e.message}")
        }
    }

    private fun parseStations(jsonData: String): List<Station> {
        val jsonObject = JSONObject(jsonData)
        val results = jsonObject.getJSONArray("results")

        val stationsList = mutableListOf<Station>()
        for (i in 0 until results.length()) {
            val obj = results.getJSONObject(i)

            val nom = obj.optString("id", "Inconnu")
            val adresse = obj.optString("address", "Non précisé")
            val ville = obj.optString("com_arm_name", "Non précisé")
            val carburants = mutableMapOf<String, Double>()

            val typesCarburants = listOf("price_gazole", "price_sp95", "price_sp98", "price_gplc", "price_e10", "price_e85")
            for (type in typesCarburants) {
                obj.optDouble(type, -1.0).takeIf { it > 0 }?.let { carburants[type] = it }
            }

            val toilettes = obj.optJSONArray("services")?.toString()?.contains("Toilettes") ?: false
            val boutique = obj.optJSONArray("services")?.toString()?.contains("Boutique") ?: false
            val gonflage = obj.optJSONArray("services")?.toString()?.contains("Gonflage") ?: false

            stationsList.add(Station(nom, adresse, ville, carburants, toilettes, gonflage, boutique))
        }

        return stationsList
    }

    var searchQuery: String by Delegates.observable("") { _, old, new ->
        pcs.firePropertyChange("searchQuery", old, new)
    }

    fun addPropertyChangeListener(listener: PropertyChangeListener) {
        pcs.addPropertyChangeListener(listener)
    }

    fun updateStations(newStations: List<Station>) {
        val oldStations = stations.toList()
        stations.clear()
        stations.addAll(newStations)
        pcs.firePropertyChange("stations", oldStations, stations)
    }
    // Getter pour accéder aux stations
    fun getStations(): List<Station> = stations
}
